
# Customer Churn Analysis Project

This project analyzes customer churn data using Python and provides insights using data visualization and a machine learning model.

## Contents

- `customer_churn_analysis.ipynb` – Jupyter notebook with full analysis and model.
- `dataset/WA_Fn-UseC_-Telco-Customer-Churn.csv` – Example customer churn dataset.
- `report.pdf` – Summary report of findings.
- `requirements.txt` – Python packages required to run the notebook.

## Getting Started

1. Install required libraries using `pip install -r requirements.txt`.
2. Open `customer_churn_analysis.ipynb` in Jupyter Notebook or VS Code.
3. Run all cells to see data exploration, visualization, and churn prediction model.

